﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs2.Offsets
{
    internal enum LoadType : byte
    {
        FROM_DIR = 0,
        FROM_GIT = 1
    }
}

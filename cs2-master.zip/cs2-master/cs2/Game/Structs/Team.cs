﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs2.Game.Structs
{
    internal enum Team : int
    {
        UNKNOWN = 0,
        Spectator = 1,
        Terrorist = 2,
        CounterTerrorist = 3
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs2.Game.Structs
{
    internal enum BombSite
    {
        _ = -1,
        A = 0,
        B = 1
    }
}

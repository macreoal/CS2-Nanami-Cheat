﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs2.Config
{
    public enum WeaponConfigType : byte
    {
        NONE = 0,
        PISTOL = 1,
        SMG = 2,
        RIFLE = 3,
        SNIPER_RIFLE = 4,
        SHOTGUN = 5
    }
}
